
module.exports = {
    secretkey: 'MicrosHeresMeSecKey'
}
